package ua.lviv.iot.builderShop;

import org.springframework.data.repository.CrudRepository;

import ua.lviv.iot.builderShop.model.BuilderGoods;

public interface GoodsRepository extends CrudRepository<BuilderGoods, Integer> {



}
