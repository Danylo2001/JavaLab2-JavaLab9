package ua.lviv.iot.builderShop.model;

public enum Resist {

    NO_RESIST, WEAK_RESIST, STRONG_RESIST;

}
