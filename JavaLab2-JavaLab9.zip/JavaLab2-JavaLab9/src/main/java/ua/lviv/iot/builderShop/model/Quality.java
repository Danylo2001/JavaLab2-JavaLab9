package ua.lviv.iot.builderShop.model;

public enum Quality {

    SHORT_TERM, MEDIUM_TERM, LONG_TERM;

}
