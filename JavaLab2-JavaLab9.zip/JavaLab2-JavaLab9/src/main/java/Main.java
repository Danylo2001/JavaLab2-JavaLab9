import ua.lviv.iot.builderShop.manager.BuilderShopManager;


import ua.lviv.iot.builderShop.model.*;
import ua.lviv.iot.builderShop.model.Quality;
import ua.lviv.iot.builderShop.model.Resist;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
		BuilderShopManager manager1 = new BuilderShopManager();
		WoodenGoods chair = new WoodenGoods("Chair", 2.4, "Wood", 80, TypeOfGoods.WOODEN_GOODS, 50,	"IKEA", 40, Resist.WEAK_RESIST, 50);
		WoodenGoods table = new WoodenGoods("Table", 10, "Wood", 90, TypeOfGoods.WOODEN_GOODS, 100, "IKEA", 120, Resist.STRONG_RESIST, 100);
		Plumbing toilet = new Plumbing("Toilet", 100, "ceramic", 100, TypeOfGoods.PLUMBING, 200, "Valve", 80, 60);
		Plumbing bath = new Plumbing("Bath", 300, "ceramic", 40, TypeOfGoods.PLUMBING, 499, "MSI", 200, 120);
		Lighting lamp = new Lighting("Lamp", 0.1, "Glass", 10, TypeOfGoods.LIGHTNING, 15, "HyperX", 5, 23, Quality.MEDIUM_TERM, true);
		Lighting lantern = new Lighting("Lantern", 2, "Glass", 25, TypeOfGoods.LIGHTNING, 50, "Razer", 15, 10, Quality.LONG_TERM, false);
		List<BuilderGoods> newBuilderGoodsList = new ArrayList<>();
        manager1.toAdd(chair);
        manager1.toAdd(table);
        manager1.toAdd(toilet);
        manager1.toAdd(bath);
        manager1.toAdd(lamp);
        manager1.toAdd(lantern);
        
        
        System.out.println(manager1.sortByPrice(true).toString());
        System.out.println(manager1.sortByPrice(false));
        System.out.println();
        System.out.println(manager1.searchByType(TypeOfGoods.PLUMBING));
        System.out.println(manager1.searchByType(TypeOfGoods.LIGHTNING));
        System.out.println();
        System.out.println(manager1.sortByWidth(true));
        System.out.println(manager1.sortByWidth(false));
	}
	

}
