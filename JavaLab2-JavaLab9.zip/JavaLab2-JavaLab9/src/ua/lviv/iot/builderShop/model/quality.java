package ua.lviv.iot.builderShop.model;

public enum quality {
	
	SHORT_TERM, MEDIUM_TERM, LONG_TERM;

}
