package ua.lviv.iot.builderShop.model;

public enum TypeOfGoods {
	
	PLUMBING, WOODEN_GOODS, LIGHTNING;
}
